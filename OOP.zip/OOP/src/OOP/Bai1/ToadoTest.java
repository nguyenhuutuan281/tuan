package OOP.Bai1;

public class ToadoTest {
    public static void main(String[] args) {
        Toado s1 = new Toado(23, 76, "A");
        System.out.println(s1);
    }
}
