package OOP;

import java.util.Scanner;

public class Test1 {
    public static void main(String[] args){
        try {
            int tuoi = nhaptuoinhanvien();
            System.out.println("Tuổi đã nhập: " + tuoi);
        } catch (Exception e) {
            System.out.println("Tuổi nhập vào chưa hợp lệ. Lỗi: " + e.toString());
        }

    }

    private static int nhaptuoinhanvien() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap tuoi: ");
        int tuoi = sc.nextInt();
        if (tuoi <= 0 || tuoi > 150) throw new Exception("tuoi phai lon hon 0 và nho hon 150");
        return tuoi;
    }
}